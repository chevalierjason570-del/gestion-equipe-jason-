# Gestion des rôles personnalisés

## Installation obligatoire dans Supabase

1. Ouvre le tableau de bord Supabase du projet.
2. Va dans **SQL Editor** puis **New query**.
3. Ouvre le fichier `supabase/roles-management.sql` de cette archive.
4. Copie tout son contenu dans l'éditeur SQL et clique sur **Run**.
5. Redéploie ensuite le projet sur Vercel.

Cette migration ajoute la table `roles`, conserve les rôles Administrateur et Standard, et permet d'enregistrer des rôles personnalisés.

## Utilisation

- Dans **Rôles**, crée un rôle, donne-lui un nom et coche ses autorisations.
- **Consulter les fichiers** autorise l'ouverture de la rubrique et la lecture des fichiers.
- **Ajouter, modifier et supprimer des fichiers** autorise aussi les opérations de gestion des fichiers.
- **Messagerie** autorise l'accès à la messagerie.
- **Paramètres** autorise l'accès à la rubrique Paramètres.
- Dans **Utilisateurs**, choisis le rôle de chaque compte dans le menu déroulant.
- Un rôle ne peut pas être supprimé tant qu'un utilisateur le possède.

Les rubriques **Utilisateurs** et **Rôles** restent réservées au rôle Administrateur. Le rôle Administrateur ne peut pas être modifié ou supprimé, et un administrateur ne peut pas retirer lui-même ses propres droits.
